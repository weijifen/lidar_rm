//个人调试使用
/****************************************
*    @author  : LD
*    @date    : 201780124
*    @ROS     : Kinetic
*    @Version : 1.0.0
****************************************/

#include "ros/ros.h"
#include <std_msgs/Empty.h>
#include <std_msgs/String.h>
#include <serial/serial.h>  //ROS已经内置了的串口包
#include <std_msgs/String.h>
#include <rplidar_ros/coordinate_msg.h>
#include <sstream>
serial::Serial ser; //声明串口对象
//from two float(horizonal,vertical) get a uint8_t(Buffer[8])
void getBuffer(uint8_t *Buffer,double coordinate_x,double coordinate_y,double angle){
    unsigned int x=(unsigned int)coordinate_x;
    unsigned int y=(unsigned int)coordinate_y;
    unsigned int ang=(unsigned int)((angle+180)*100);
    Buffer[0] = x & 0xff;
    Buffer[1] = x >> 8;
    Buffer[2] = y & 0xff;
    Buffer[3] = y >> 8;
    Buffer[4] = ang & 0xff;
    Buffer[5] = ang >> 8;

    // unsigned int hor=((unsigned int*)&(horizonal))[0];
    // unsigned int ver=((unsigned int*)&(vertical))[0];
    // for(int i=0;i<4;i++){
    //     uint8_t tmp=(hor>>(8*i))&0xff;
    //     Buffer[i]=tmp;
    //     //printf("%x ",tmp);
    // }
    // //printf("\n");
    // for(int i=0;i<4;i++){
    //     uint8_t tmp=(ver>>(8*i))&0xff;
    //     Buffer[i+4]=tmp;
    //     //printf("%x ",tmp);
    // }
}
//from  a uint8_t(Buffer[8])  get two float(horizonal,vertical)
// void getData(uint8_t *Buffer,float &horizonal,float &vertical){
//     unsigned int hor=0,ver=0;
//     //printf("\n");
//     for(int i=3;i>=0;i--){
//         hor+=Buffer[i];
//         if (i!=0)hor=hor<<8;
//         //printf("Buffer[%d]:%x,hor:%x\n",i,Buffer[i],hor);
//     }
//     //printf("\n");
//     for(int i=7;i>=4;i--){
//         ver+=Buffer[i];
//         if (i!=4)ver=ver<<8;
//         //printf("Buffer[%d]:%x,ver:%d\n",i,Buffer[i],ver);
//     }
//     horizonal=((float*)&hor)[0];
//     vertical=((float*)&ver)[0];
//     //cout<<*horizonal<<endl;
//     //cout<<*vertical<<endl;
// }
// //from  a string  get two float(horizonal,vertical)
// void getData(std::string str,float &horizonal,float &vertical){

//     if(str.size()==0){
//         printf("Reading Size Wrong:%d\n",str.size());
//         return;
//     }

//     uint8_t Buffer[8];
//     for(int i=0;i<8;i++){
//         Buffer[i]=(char)str[i];
//     }
//     getData(Buffer,horizonal,vertical);
// }
void write_callback(const rplidar_ros::coordinate_msg::ConstPtr& scan)
{
    uint8_t Buffer[6];
    ROS_INFO(": [serial_common:%05.1lf  %05.1lf  %03.1lf]", scan->coordinate_x, scan->coordinate_y, scan->angle);
    double coordinate_x=scan->coordinate_x;
    double coordinate_y=scan->coordinate_y;
    double angle=scan->angle;
    getBuffer(Buffer,coordinate_x,coordinate_y,angle);

    // float horizonal=msg->horizonal;
    // float vertical=msg->vertical;
    // getBuffer(Buffer,horizonal,vertical);
    //printf("write succeed.h:%f,\tv:%f.\n",horizonal,vertical);

    ser.write(Buffer,6);   //发送串口数据
}


int main (int argc, char** argv)
{
    //初始化节点
    ros::init(argc, argv, "serial_common_node");
    //声明节点句柄
    ros::NodeHandle nh;
    // ros::Publisher scan_pub = nh.advertise<rplidar_ros::coordinate_msg>("scan", 1000);
    //订阅主题，并配置回调函数
    ros::Subscriber write_sub = nh.subscribe("scan",1,write_callback);

    //发布主题
    ros::Publisher read_pub = nh.advertise<std_msgs::String>("/serial/read", 1);


    try
    {
        //设置串口属性，并打开串口
        ser.setPort("/dev/ttyACM0");
        ser.setBaudrate(115200);
        serial::Timeout to = serial::Timeout::simpleTimeout(1000);
        ser.setTimeout(to);
        ser.open();
    }
    catch (serial::IOException& e)
    {
        ROS_ERROR_STREAM("Unable to open port ");
        return -1;
    }
    //检测串口是否已经打开，并给出提示信息
    if(ser.isOpen())
    {
        ROS_INFO_STREAM("Serial Port initialized");
    }
    else
    {
        return -1;
    }



    // // float horizonal=0,vertical=0;
    // // serial_common::wind_mill_msg msg;
    ros::Rate loop_rate(1000);
    int count = 0;
    while(ros::ok())
    {
        if(true){//ser.available()
            // ROS_INFO_STREAM("Reading from serial port\n");
            std_msgs::String result;
            result.data = ser.read(ser.available());
            ROS_INFO_STREAM("Read: " << result.data);
            // getData(result.data,horizonal,vertical);
            // msg.horizonal=horizonal;
            // msg.vertical=vertical;
            // if(horizonal==0 || horizonal==1.0 || vertical==0 || vertical==1.0)ROS_INFO_STREAM("After solving,h:" << horizonal<<",v:"<<vertical);
            read_pub.publish(result);

            // std_msgs::String msg;

            // std::stringstream ss;
            // ss << "hello world " << count;
            // // ROS_INFO(": [serial_common:hello world %d]", count);
            // msg.data = ss.str();

            // read_pub.publish(msg);
            // count++;

        }

        //处理ROS的信息，比如订阅消息,并调用回调函数
        ros::spinOnce();
        loop_rate.sleep();
        

    }



}